# Welcome to your brand new NodeBB forum!

This is what a topic and post looks like. As an administrator, you can edit the post\'s title and content.
To customise your forum, go to the [Administrator Control Panel](../../admin). You can modify all aspects of your forum there, including installation of third-party plugins.

## Additional Resources

* [NodeBB Documentation](https://docs.nodebb.org)
* [Community Support Forum](https://community.nodebb.org)
* [Project repository](https://github.com/nodebb/nodebb)
